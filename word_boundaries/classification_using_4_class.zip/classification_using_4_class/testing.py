import numpy as np
from keras.preprocessing.text import one_hot
import librosa
import os
from keras.utils import to_categorical
from keras.preprocessing.sequence import pad_sequences
#PATH='/home/manoj/Desktop/assignment3/toy/test'
y=[]
docs=[] 
def max_size2(PATH):
    docs=[]   
    folders=os.listdir(PATH)       
    for i in folders:
           PATH1=PATH+'/'+i
           folders1=os.listdir(PATH1)
           for j in folders1:
                PATH2=PATH1+'/'+j
                folders2=os.listdir(PATH2)
                for k in folders2:
                      if 'wav' in k:
                             PATH3=PATH2+'/'+k
                             #print(k)
                             y_val, sr = librosa.load(PATH3,sr=None)
                             docs.append(y_val)
   
    max_size2=docs[0].size
    for i in range(len(docs)):
           if docs[i].size>max_size2:
                  max_size2=docs[i].size
                  #print(i)
    
    return max_size2


def func(PATH3,max_size):
    
      with open (PATH3, "r") as myfile:
                               a=[]
                               b=[]
                               for line in myfile:
                                      #line=line[8:]
                                      #print(line)
                                      for l in range(len(line)):
                                             
                                             if line[l]==' ':
                                                 a.append(line[0:l])
                                                 k=l
                                                 break
                                                 
                                      for j in range(k+1,len(line)) :           
                                             if line[j]==' ':    
                                                 b.append(line[k+1:j])
                                                 break
                               a=[int(i) for i in a]
                               b=[int(i) for i in b]
                               
                               a=np.array(a)
                               b=np.array(b)
                               #print(a)
                               l=len(a)
                               #print("VALIDATION")
                               #print("max_size",max_size)
                               y_temp=np.zeros(max_size)
                               
                               for i in range(a[0]):
                                   y_temp[i]=3
                               for j in range(l-1):
                                   for k in range(b[j]+1,a[j+1]):
                                       y_temp[k]=3
                               for i in range(b[l-1]+1,max_size):
                                   y_temp[i]=3        
                               for m in range(l):
                                   for n in range(a[m],b[m]+1):
                                       y_temp[n]=2
                               for o in range(l):
                                   y_temp[a[o]]=0
                                   y_temp[b[o]]=1
                                       
                                       
                               #y.append(y_temp)
                               return y_temp



def testingdata_Xy(max_size,PATH):
    while 1:
        start=0
        end=1 
        mid=2
        space=3
        y=[]
        docs=[]   
        folders=os.listdir(PATH)       
        for i in folders:
               PATH1=PATH+'/'+i
               folders1=os.listdir(PATH1)
               for j in folders1:
                    PATH2=PATH1+'/'+j
                    folders2=os.listdir(PATH2)
                    for k in folders2:
                          if 'wav' in k:
                                 PATH3=PATH2+'/'+k
                                 #print(PATH3)
                                 y_val, sr = librosa.load(PATH3,sr=None)
                                 
                                 #print("Y_VAL")
                                 y_val1 = np.array([y_val[:,]])
                                 #print(y_val.shape)
                                 y_val1 = np.transpose(y_val1)
                                 #print(y_val1.shape)
                                 docs.append(y_val1)
                                 
                                 k1=k.split('.')[0]
                          #if 'wrd' in k:
                                 PATH3=PATH2+'/'+k1+'.wrd'
                                 #print(PATH3)
                                 val=func(PATH3,max_size)
                                 val1=np.array([val[:,]])
                                 val1 = np.transpose(val1)
                                 #print(val1.shape)
                                 y.append(val1)
                        
                        
                        
   
        #max_size=docs[0].size
        for i in range(len(docs)):
               if docs[i].size>max_size:
                      max_size=docs[i].size
                      #print(i)
        
        
        
        for j in range(len(docs)):
          diff=max_size- (docs[j].shape[0])
          z = np.zeros((diff,1), dtype=docs[j].dtype)
          docs[j]=np.concatenate((docs[j],z), axis=0)
        #print("hello")
        # print(type(docs))
        # print(len(docs))
        # print(docs[0].shape)
        # print(type(y))
        # print(len(y))
        # print(y[0].shape) 
        X=np.array(docs) 
        y=np.array(y)
        #print(X.shape[0])
        #print(y.shape)
        # for j in range(max_size):
        #   y_temp = []
        #   a = y[j,:,:]
        #   print(a.shape)
        #   a.shape = a.shape[0] 
        #   y_temp = a
        #   print(a.shape)
        #   print(len(y_temp))
        #   y[j, :, :] = to_categorical(y_temp, num_classes=4)
        batch_size = X.shape[0]
        steps = max_size
        dictionary = 4
        label = np.zeros((batch_size, steps,dictionary))
        for batch in range(batch_size):
          a = []
          # b= y[batch,:,:]
          # b.shape = b.shape[0]
          # print('b.shape',b.shape)
          # for steps in b:
          #   a.append(b)
          # print(len(a))
          for i in range(steps):
            a.append(y[batch,i,:])
          label[batch,:,:] = to_categorical(a,num_classes =4)

        #print("X-shape",X.shape)
        #print("label-shape",label.shape)
        return X   
        #yield docs,y

if __name__== "__main__":
   X,y=trainingdata_Xy()
   
   
   
