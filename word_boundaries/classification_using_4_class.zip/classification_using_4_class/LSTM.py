#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 23 15:11:35 2018

@author: priyank
"""

from keras.models import Sequential  
from keras.layers.core import Dense, Activation  
from keras.layers.recurrent import LSTM
from traindata_new import max_size1
from validation import max_size2
from traindata_new import trainingdata_Xy
from validation import validationdata_Xy
from testing import testingdata_Xy
import numpy as np
from keras.optimizers import Adam, RMSprop
import collections
import os
import tensorflow as tf
from keras.models import Sequential, load_model
from keras.layers import Dense, Activation, Embedding, Flatten, Dropout, TimeDistributed, Reshape, Lambda
from keras.layers import LSTM
from keras.optimizers import RMSprop, Adam, SGD
from keras import backend as K
from keras.utils import to_categorical
from keras.callbacks import ModelCheckpoint
import numpy as np
max_size1=max_size1('/home/manoj/Desktop/assignment3/toy/DL_ASS_3_data_toy')
#max_size1=max_size()
print(max_size1)
max_size2=max_size2('/home/manoj/Desktop/assignment3/toy/test')
print(max_size2)
if max_size1>max_size2:
	max_size = max_size1
else:
 	max_size = max_size2
print("max size",max_size)
train = trainingdata_Xy(max_size,'/home/manoj/Desktop/assignment3/toy/DL_ASS_3_data_toy')
validation = validationdata_Xy(max_size,'/home/manoj/Desktop/assignment3/toy/test')
testing = testingdata_Xy(max_size,"/home/manoj/Desktop/assignment3/toy/testing")
print("testing.shape",testing.shape)
"""def generate(self):
    x = np.zeros((self.batch_size, self.num_steps))
    y = np.zeros((self.batch_size, self.num_steps, self.vocabulary))
    while True:
        for i in range(self.batch_size):
            if self.current_idx + self.num_steps >= len(self.data):
                # reset the index back to the start of the data set
                self.current_idx = 0
            x[i, :] = self.data[self.current_idx:self.current_idx + self.num_steps]
            temp_y = self.data[self.current_idx + 1:self.current_idx + self.num_steps + 1]
            # convert all of temp_y into a one hot representation
            y[i, :, :] = to_categorical(temp_y, num_classes=self.vocabulary)
            self.current_idx += self.skip_step
        yield x, y
num_steps = max_size
batch_size = 30
hidden_size = 5
use_dropout=True
model = Sequential()
vocabulary = 4
model.add(LSTM(hidden_size, input_shape= (max_size,1), return_sequences=True))
#model.add(LSTM(hidden_size, return_sequences=True))
if use_dropout:
     model.add(Dropout(0.5))
# #model.add(TimeDistributed(Dense(vocabulary)))
#model.add(Dense(4))
model.add(TimeDistributed(Dense(vocabulary)))
model.add(Activation('softmax'))
optimizer = Adam()
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['categorical_accuracy'])
print(model.summary())
# #checkpointer = ModelCheckpoint(filepath=data_path + '/model-{epoch:02d}.hdf5', verbose=1)
num_epochs = 2
model.fit_generator(train, 4, num_epochs,
                    validation_data=validation,
                    validation_steps=1)
model.save("/home/manoj/Desktop/assignment3/toy/lstm.h5")"""
model1 = load_model("/home/manoj/Desktop/assignment3/toy/lstm.h5")
print(np.argmax(model1.predict(testing),axis = 0))